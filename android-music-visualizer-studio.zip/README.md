# Offline Music Visualizer Studio

A Specterr-style music visualizer editor that runs entirely on-device, offline.

## What it is (honestly)
Built with React + Vite + Tailwind as a single self-contained `dist/index.html`.
It is **not** a native Kotlin/Jetpack Compose APK — that cannot be produced in this web build environment.
Equivalent engines are used: Web Audio decode + own radix-2 FFT (instead of Android Audio APIs),
Canvas 2D (instead of OpenGL ES), WebCodecs + mp4-muxer (instead of MediaCodec/MediaMuxer), IndexedDB (instead of Room).

## Implemented
- 36 original templates in 12 categories; previews are rendered from the real FFT of a locally synthesized demo track
- 14 audio-reactive visualizer styles driven by FFT, plus beat detection
- Layered editor: move/resize/rotate/opacity, duplicate, reorder, undo/redo, autosave (IndexedDB)
- Backgrounds: solid, gradient, animated, image, video (blur, opacity, scale/crop, position)
- Text layers (bundled fonts, gradient, outline, glow, shadow, animations) and lyrics (manual, .txt/.lrc import, tap-to-sync)
- Effects: neon bloom, RGB split, glitch, blur, motion blur, light rays, particles, wave distortion, flash, vignette, colour correction
- Audio import (whatever the device decoder supports), trim, volume
- Export: offline frame-exact MP4 (H.264, H.265 where an encoder exists) + AAC, 24/30/60 fps, resolutions only where the
  device encoder reports support, progress + cancel. Real-time MediaRecorder fallback (<=1080p) without WebCodecs.

## Limitations
- Tested in headless Chromium: UI, FFT previews, playback, and the video-encode/MP4-mux path (output verified decodable).
  The AAC audio path could not run there (no AAC encoder in that build) — verify on a real Chrome/Android device.
- The MP4 is assembled in memory: long 4K exports can exhaust RAM on phones.
- "Save to Gallery" = Download to Downloads or the Share sheet; a browser cannot write to MediaStore directly.
- Exporting needs the page open and the screen on.

## Getting an APK
Wrap `dist/` with Capacitor (`npx cap add android`, set webDir to `dist`, open in Android Studio, build debug/release APK).
