import { Bookmark, Pencil, Trash2, Wand2 } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import type { NewDlgState } from "../components/NewProjectDialog";
import { Button, IconBtn, Modal, TextInput } from "../components/ui";
import { db } from "../lib/db";
import type { SavedDesign } from "../lib/types";

export function Designs({ startNew }: { startNew: (s: NewDlgState) => void }) {
  const [list, setList] = useState<SavedDesign[] | null>(null);
  const [rename, setRename] = useState<SavedDesign | null>(null);
  const [name, setName] = useState("");
  const load = useCallback(() => db.listDesigns().then((l) => setList(l.sort((a, b) => b.createdAt - a.createdAt))), []);
  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="anim-in mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-8 sm:pt-10">
      <h1 className="text-2xl font-bold sm:text-3xl">Saved Designs</h1>
      <p className="mt-1 text-sm text-zinc-400">Your own reusable looks (layers, background and effects). Save one from the editor’s Project tab.</p>
      {list && list.length === 0 && (
        <div className="mt-10 grid place-items-center rounded-2xl border border-dashed border-white/10 p-12 text-center text-sm text-zinc-500">
          <Bookmark className="mb-3 text-zinc-600" />
          No saved designs yet. Open a project and choose “Save current look as design”.
        </div>
      )}
      <div className="mt-5 grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 lg:grid-cols-3">
        {list?.map((d) => (
          <div key={d.id} className="overflow-hidden rounded-2xl border border-white/[0.06] bg-ink-800">
            <div className="aspect-video bg-ink-700">{d.thumbnail && <img src={d.thumbnail} className="h-full w-full object-cover" alt="" />}</div>
            <div className="flex items-center justify-between gap-2 p-3">
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold">{d.name}</div>
                <div className="text-[11px] text-zinc-500">{new Date(d.createdAt).toLocaleDateString()}</div>
              </div>
              <div className="flex">
                <Button size="sm" variant="soft" onClick={() => startNew({ design: d })}>
                  <Wand2 size={14} /> Use
                </Button>
                <IconBtn
                  onClick={() => {
                    setRename(d);
                    setName(d.name);
                  }}
                >
                  <Pencil size={16} />
                </IconBtn>
                <IconBtn
                  className="hover:text-red-400"
                  onClick={async () => {
                    await db.deleteDesign(d.id);
                    load();
                  }}
                >
                  <Trash2 size={16} />
                </IconBtn>
              </div>
            </div>
          </div>
        ))}
      </div>
      <Modal open={!!rename} onClose={() => setRename(null)} title="Rename design">
        <TextInput value={name} onChange={(e) => setName(e.target.value)} autoFocus />
        <div className="mt-4 flex justify-end gap-2">
          <Button onClick={() => setRename(null)}>Cancel</Button>
          <Button
            variant="primary"
            onClick={async () => {
              if (rename && name.trim()) await db.putDesign({ ...rename, name: name.trim() });
              setRename(null);
              load();
            }}
          >
            Save
          </Button>
        </div>
      </Modal>
    </div>
  );
}
