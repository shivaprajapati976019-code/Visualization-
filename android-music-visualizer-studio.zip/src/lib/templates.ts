import type {
  Aspect,
  Background,
  Effects,
  Layer,
  LyricLine,
  LyricsLayer,
  Project,
  Template,
  TemplateCategory,
  TextLayer,
  VisualizerLayer,
} from "./types";
import { deepClone, uid } from "./util";

export const defaultBg = (p: Partial<Background> = {}): Background => ({
  type: "gradient",
  color: "#0b0b14",
  color2: "#1b1033",
  angle: 135,
  animStyle: "aurora",
  mediaId: null,
  mediaName: "",
  blur: 0,
  opacity: 1,
  scale: 1,
  offsetX: 0,
  offsetY: 0,
  fit: "cover",
  dim: 0,
  reactiveZoom: 0,
  ...p,
});

export const defaultEffects = (p: Partial<Effects> = {}): Effects => ({
  neonGlow: 0,
  rgb: 0,
  glitch: 0,
  blur: 0,
  motionBlur: 0,
  lightRays: 0,
  particles: 0,
  waveDistortion: 0,
  flash: 0,
  vignette: 0,
  brightness: 1,
  contrast: 1,
  saturation: 1,
  hue: 0,
  rayColor: "#8a7bff",
  particleColor: "#ffffff",
  ...p,
});

export const vis = (p: Partial<VisualizerLayer> = {}): VisualizerLayer => ({
  id: uid(),
  type: "visualizer",
  name: "Visualizer",
  visible: true,
  x: 0.5,
  y: 0.5,
  scale: 1,
  rotation: 0,
  opacity: 1,
  start: 0,
  end: 0,
  style: "circularSpectrum",
  colorMode: "gradient",
  color1: "#00f0ff",
  color2: "#ff00e5",
  bars: 96,
  thickness: 0.6,
  amp: 1,
  smoothing: 0.5,
  rounded: true,
  glow: 0.4,
  spin: 0,
  inner: 1,
  reactiveScale: 0.3,
  ...p,
});

export const textDefaults = {
  text: "Song Title",
  fontFamily: "Inter",
  fontSize: 72,
  bold: true,
  italic: false,
  color: "#ffffff",
  gradient: false,
  color2: "#8a7bff",
  letterSpacing: 0,
  align: "center" as const,
  shadow: 0,
  shadowColor: "#000000",
  outline: 0,
  outlineColor: "#000000",
  glow: 0,
  glowColor: "#8a7bff",
  anim: "fade" as const,
};

export const txt = (p: Partial<TextLayer> = {}): TextLayer => ({
  id: uid(),
  type: "text",
  kind: "custom",
  name: "Text",
  visible: true,
  x: 0.5,
  y: 0.9,
  scale: 1,
  rotation: 0,
  opacity: 1,
  start: 0,
  end: 0,
  ...textDefaults,
  ...p,
});

export const lyr = (p: Partial<LyricsLayer> = {}): LyricsLayer => ({
  id: uid(),
  type: "lyrics",
  name: "Lyrics",
  visible: true,
  x: 0.5,
  y: 0.82,
  scale: 1,
  rotation: 0,
  opacity: 1,
  start: 0,
  end: 0,
  ...textDefaults,
  text: "",
  fontSize: 64,
  anim: "none",
  transition: "fade",
  boxColor: "#000000",
  boxOpacity: 0,
  showNext: false,
  ...p,
});

const title = (p: Partial<TextLayer> = {}) =>
  txt({ kind: "title", name: "Song Title", text: "Song Title", y: 0.86, fontSize: 64, ...p });
const artist = (p: Partial<TextLayer> = {}) =>
  txt({ kind: "artist", name: "Artist Name", text: "Artist Name", y: 0.93, fontSize: 32, bold: false, letterSpacing: 6, opacity: 0.8, anim: "fade", ...p });

const SAMPLE_LYRICS = (): LyricLine[] => [
  { id: uid(), start: 1, end: 5, text: "Your lyrics appear right here" },
  { id: uid(), start: 5, end: 9, text: "Edit timing in the Lyrics tab" },
  { id: uid(), start: 9, end: 13, text: "Tap-to-sync while the song plays" },
  { id: uid(), start: 13, end: 17, text: "Every line is fully animated" },
];

let order = 0;
const T = (
  name: string,
  category: TemplateCategory,
  description: string,
  palette: string[],
  styleLabel: string,
  background: Background,
  effects: Effects,
  layers: Layer[],
  lyrics?: LyricLine[]
): Template => ({
  id: `${category.toLowerCase()}-${++order}`,
  name,
  category,
  description,
  palette,
  styleLabel,
  background,
  effects,
  layers,
  lyrics,
});

const bar = { y: 0.74, scale: 0.9 };

export const TEMPLATES: Template[] = [
  // ------------------------------------------------------------ Circular
  T("Neon Pulse Ring", "Circular", "Glowing spectrum ring that breathes with the kick.", ["#00f0ff", "#ff00e5", "#0b0b1a"], "Circular Spectrum",
    defaultBg({ color: "#060612", color2: "#1a0b2e" }), defaultEffects({ neonGlow: 0.35, vignette: 0.4 }),
    [vis({ name: "Ring", y: 0.46, scale: 0.95, glow: 0.7 }), title({ fontFamily: "Orbitron", letterSpacing: 8, fontSize: 54 }), artist({ fontFamily: "Orbitron" })]),
  T("Orbit Wave", "Circular", "Flowing waveform ring over a slow aurora.", ["#5cffc8", "#3b7bff", "#04121f"], "Circular Waveform",
    defaultBg({ type: "animated", animStyle: "aurora", color: "#031a2b", color2: "#2563eb" }), defaultEffects({ neonGlow: 0.3 }),
    [vis({ name: "Wave ring", style: "circularWave", color1: "#5cffc8", color2: "#3b7bff", y: 0.46, thickness: 0.5, amp: 1.2, glow: 0.6 }),
      title({ fontFamily: "Space Grotesk", fontSize: 58 }), artist({ fontFamily: "Space Grotesk" })]),
  T("Solar Bloom", "Circular", "Radial flare with warm rays and pulsing backdrop.", ["#ffb347", "#ff3d3d", "#1a0606"], "Radial Spectrum",
    defaultBg({ type: "animated", animStyle: "pulse", color: "#1a0505", color2: "#ff5a1f" }), defaultEffects({ lightRays: 0.5, rayColor: "#ff9a3c", vignette: 0.4 }),
    [vis({ name: "Bloom", style: "radialSpectrum", color1: "#ffd24a", color2: "#ff3d1f", y: 0.46, glow: 0.5, spin: 8 }),
      title({ fontFamily: "Righteous", fontSize: 58 }), artist()]),

  // ------------------------------------------------------------ Spectrum
  T("Skyline Bars", "Spectrum", "Wide city-skyline spectrum under a starry sky.", ["#a855f7", "#22d3ee", "#07071a"], "Linear Spectrum",
    defaultBg({ type: "animated", animStyle: "stars", color: "#05051a", color2: "#1a1048", angle: 180 }), defaultEffects({ neonGlow: 0.2 }),
    [vis({ name: "Spectrum", style: "linearSpectrum", color1: "#a855f7", color2: "#22d3ee", ...bar, bars: 72, rounded: true }), title({ y: 0.2, fontSize: 60 }), artist({ y: 0.27 })]),
  T("Prism Bars", "Spectrum", "Rainbow frequency bars with peak caps and reflection.", ["#ff4d6d", "#ffd93d", "#4dffb8"], "Frequency Bars",
    defaultBg({ color: "#08080c", color2: "#111120", angle: 180 }), defaultEffects({ vignette: 0.3 }),
    [vis({ name: "Bars", style: "frequencyBars", colorMode: "rainbow", y: 0.55, scale: 0.9, bars: 64, glow: 0.3, thickness: 0.7 }), title({ y: 0.17, fontFamily: "Bebas Neue", fontSize: 90, letterSpacing: 10 }), artist({ y: 0.25 })]),
  T("Sunset Drive", "Spectrum", "Retro synthwave grid with a hot pink spectrum.", ["#ff3cac", "#ffb86b", "#1b0a3a"], "Linear Spectrum",
    defaultBg({ type: "animated", animStyle: "grid", color: "#12062e", color2: "#ff3cac", angle: 180 }), defaultEffects({ neonGlow: 0.35 }),
    [vis({ name: "Spectrum", style: "linearSpectrum", color1: "#ffb86b", color2: "#ff3cac", y: 0.52, scale: 0.9, bars: 64, glow: 0.6 }), title({ y: 0.2, fontFamily: "Righteous", fontSize: 70, gradient: true, color: "#ffb86b", color2: "#ff3cac" }), artist({ y: 0.28 })]),

  // ------------------------------------------------------------ Waveform
  T("Clean Line", "Waveform", "A single crisp waveform on pure black.", ["#ffffff", "#8a8a8a", "#000000"], "Audio Waveform",
    defaultBg({ type: "solid", color: "#000000" }), defaultEffects(),
    [vis({ name: "Waveform", style: "waveform", colorMode: "solid", color1: "#ffffff", y: 0.5, thickness: 0.3, amp: 1.1, glow: 0.15 }), title({ y: 0.82, fontSize: 48 }), artist({ y: 0.88 })]),
  T("Ribbon Flow", "Waveform", "Symmetric ribbon waveform with teal-violet gradient.", ["#2dd4bf", "#8b5cf6", "#06101a"], "Symmetrical Waveform",
    defaultBg({ type: "animated", animStyle: "aurora", color: "#04101c", color2: "#4c1d95" }), defaultEffects({ neonGlow: 0.25 }),
    [vis({ name: "Ribbon", style: "symmetricWave", color1: "#2dd4bf", color2: "#8b5cf6", y: 0.48, amp: 1.2, glow: 0.4 }), title({ y: 0.86 }), artist()]),
  T("Wave Echo", "Waveform", "Layered waveforms with long motion-blur trails.", ["#ff6ec7", "#6ee7ff", "#0a0618"], "Multiple Waveforms",
    defaultBg({ color: "#07040f", color2: "#150a2a" }), defaultEffects({ motionBlur: 0.55, neonGlow: 0.3 }),
    [vis({ name: "Echo A", style: "waveform", colorMode: "solid", color1: "#ff6ec7", y: 0.48, thickness: 0.35, glow: 0.7, rotation: -4 }),
      vis({ name: "Echo B", style: "waveform", colorMode: "solid", color1: "#6ee7ff", y: 0.52, thickness: 0.35, glow: 0.7, rotation: 4 }), title({ y: 0.88, fontSize: 52 })]),

  // ------------------------------------------------------------ Equalizer
  T("Classic LED", "Equalizer", "Old-school segmented LED equalizer.", ["#39ff14", "#ff2d2d", "#050505"], "Vertical Equalizer",
    defaultBg({ type: "solid", color: "#050505" }), defaultEffects({ vignette: 0.3 }),
    [vis({ name: "LED EQ", style: "verticalEq", color1: "#39ff14", color2: "#ff2d2d", y: 0.5, bars: 36, rounded: false, thickness: 0.8, glow: 0.3 }), title({ fontFamily: "Press Start 2P", fontSize: 36, y: 0.84 }), artist({ y: 0.9, fontFamily: "Press Start 2P", fontSize: 18 })]),
  T("Stack Rows", "Equalizer", "Horizontal block-stack equalizer in cool blues.", ["#38bdf8", "#1d4ed8", "#050a18"], "Horizontal Equalizer",
    defaultBg({ color: "#040814", color2: "#0b1a3a" }), defaultEffects({ neonGlow: 0.2 }),
    [vis({ name: "Rows", style: "horizontalEq", color1: "#38bdf8", color2: "#1d4ed8", y: 0.46, bars: 80, glow: 0.35 }), title({ y: 0.86 }), artist()]),
  T("Studio Meters", "Equalizer", "Amber level meters on a dark graphite panel.", ["#fbbf24", "#f97316", "#18181b"], "Vertical Equalizer",
    defaultBg({ color: "#141416", color2: "#0a0a0c", angle: 180 }), defaultEffects({ vignette: 0.5 }),
    [vis({ name: "Meters", style: "verticalEq", color1: "#fbbf24", color2: "#f97316", y: 0.48, bars: 24, rounded: true, thickness: 0.7, glow: 0.2 }), title({ fontFamily: "Space Grotesk", y: 0.85 }), artist()]),

  // ------------------------------------------------------------ Particle
  T("Stardust Burst", "Particle", "Audio-reactive particle bursts on every beat.", ["#ff9ff3", "#feca57", "#0a0618"], "Reactive Particles",
    defaultBg({ type: "animated", animStyle: "stars", color: "#07041a", color2: "#1b0b3a" }), defaultEffects({ neonGlow: 0.3 }),
    [vis({ name: "Burst", style: "particles", color1: "#ff9ff3", color2: "#feca57", y: 0.46, glow: 0.7, amp: 1.2 }), title({ fontFamily: "Dancing Script", fontSize: 84, y: 0.86 }), artist()]),
  T("Warp Tunnel", "Particle", "3D star tunnel that accelerates with the music.", ["#22d3ee", "#e0f2fe", "#000000"], "3D Particle Field",
    defaultBg({ type: "solid", color: "#000005" }), defaultEffects({ neonGlow: 0.2 }),
    [vis({ name: "Tunnel", style: "particles3d", color1: "#22d3ee", color2: "#e0f2fe", y: 0.5, amp: 1.3, glow: 0.5 }), title({ y: 0.86, fontFamily: "Orbitron", fontSize: 50 }), artist({ fontFamily: "Orbitron" })]),
  T("Ember Rise", "Particle", "Warm embers drifting over a smoldering gradient.", ["#ff6b35", "#ffd166", "#1a0505"], "Reactive Particles",
    defaultBg({ color: "#1a0503", color2: "#3d0f08", angle: 0 }), defaultEffects({ particles: 0.7, particleColor: "#ffb347", vignette: 0.5 }),
    [vis({ name: "Embers", style: "particles", color1: "#ff6b35", color2: "#ffd166", y: 0.5, glow: 0.8 }), title({ fontFamily: "Playfair Display", y: 0.86, fontSize: 62 }), artist()]),

  // ------------------------------------------------------------ Neon
  T("Neon Mirror", "Neon", "Mirrored neon tube spectrum with heavy bloom.", ["#ff2bd6", "#4d7cff", "#06020f"], "Neon Spectrum",
    defaultBg({ color: "#05010d", color2: "#12042a" }), defaultEffects({ neonGlow: 0.8, vignette: 0.4 }),
    [vis({ name: "Neon", style: "neonSpectrum", color1: "#ff2bd6", color2: "#4d7cff", y: 0.46, bars: 64, thickness: 0.6 }), title({ fontFamily: "Pacifico", fontSize: 78, glow: 0.9, glowColor: "#ff2bd6", y: 0.86 }), artist()]),
  T("Tube Light", "Neon", "Symmetric glowing bars in cyan and green.", ["#00ffd5", "#3bff6b", "#021310"], "Mirror Spectrum",
    defaultBg({ color: "#010a0a", color2: "#04201c" }), defaultEffects({ neonGlow: 0.6 }),
    [vis({ name: "Mirror", style: "mirrorSpectrum", color1: "#00ffd5", color2: "#3bff6b", y: 0.47, bars: 56, glow: 0.8 }), title({ fontFamily: "Orbitron", glow: 0.8, glowColor: "#00ffd5", y: 0.86, fontSize: 52 }), artist()]),
  T("Laser Grid", "Neon", "Combined ring visualizer over a laser horizon.", ["#ff4fd8", "#27e8ff", "#0a0420"], "Combined Visualizers",
    defaultBg({ type: "animated", animStyle: "grid", color: "#0a0420", color2: "#27e8ff", angle: 180 }), defaultEffects({ neonGlow: 0.6, rgb: 0.2 }),
    [vis({ name: "Core", style: "combo", color1: "#ff4fd8", color2: "#27e8ff", y: 0.45, scale: 0.85, glow: 0.7 }), title({ fontFamily: "Orbitron", y: 0.9, fontSize: 44 })]),

  // ------------------------------------------------------------ Minimal
  T("Mono Bars", "Minimal", "Thin white bars. Nothing more.", ["#ffffff", "#bdbdbd", "#0b0b0b"], "Linear Spectrum",
    defaultBg({ type: "solid", color: "#0b0b0b" }), defaultEffects(),
    [vis({ name: "Bars", style: "linearSpectrum", colorMode: "solid", color1: "#ffffff", y: 0.5, bars: 48, thickness: 0.28, rounded: false, glow: 0, amp: 0.9 }), title({ y: 0.84, fontSize: 40, bold: false, letterSpacing: 12 }), artist({ y: 0.9 })]),
  T("Soft Circle", "Minimal", "A delicate ring of hairline bars.", ["#f5f5f5", "#a3a3a3", "#111111"], "Circular Spectrum",
    defaultBg({ type: "solid", color: "#111111" }), defaultEffects(),
    [vis({ name: "Ring", colorMode: "solid", color1: "#f5f5f5", y: 0.46, bars: 64, thickness: 0.22, glow: 0, rounded: true, reactiveScale: 0.1 }), title({ fontSize: 40, bold: false, letterSpacing: 10, y: 0.86 }), artist()]),
  T("Paper Mirror", "Minimal", "Ink-dark mirrored bars on warm paper.", ["#1f1f1f", "#d97706", "#f3ede2"], "Mirror Spectrum",
    defaultBg({ type: "solid", color: "#f3ede2" }), defaultEffects(),
    [vis({ name: "Ink", style: "mirrorSpectrum", colorMode: "solid", color1: "#1f1f1f", y: 0.5, bars: 40, thickness: 0.45, rounded: true, glow: 0 }),
      title({ color: "#1f1f1f", fontFamily: "Playfair Display", y: 0.84, fontSize: 56 }), artist({ color: "#1f1f1f", y: 0.9 })]),

  // ------------------------------------------------------------ Futuristic
  T("Cyber Core", "Futuristic", "Reactor-style combined ring with RGB split.", ["#00e5ff", "#2979ff", "#02060f"], "Combined Visualizers",
    defaultBg({ type: "animated", animStyle: "grid", color: "#020814", color2: "#2979ff", angle: 180 }), defaultEffects({ rgb: 0.45, neonGlow: 0.4 }),
    [vis({ name: "Core", style: "combo", color1: "#00e5ff", color2: "#2979ff", y: 0.46, spin: 12, scale: 0.9, glow: 0.6 }), title({ fontFamily: "Orbitron", y: 0.88, fontSize: 48, letterSpacing: 10 }), artist({ fontFamily: "Orbitron" })]),
  T("Hologram", "Futuristic", "Glitching teal hologram that tears on the beat.", ["#2affc9", "#0ea5e9", "#021416"], "Radial Spectrum",
    defaultBg({ color: "#011012", color2: "#03282b", angle: 180 }), defaultEffects({ glitch: 0.6, rgb: 0.5, waveDistortion: 0.15, neonGlow: 0.3 }),
    [vis({ name: "Holo", style: "radialSpectrum", color1: "#2affc9", color2: "#0ea5e9", y: 0.46, glow: 0.5 }), title({ fontFamily: "Orbitron", y: 0.88, fontSize: 46, color: "#2affc9" }), artist({ fontFamily: "Orbitron" })]),
  T("Quantum Field", "Futuristic", "Particle field with a wave ring at its centre.", ["#a78bfa", "#38bdf8", "#050510"], "3D Particles + Wave",
    defaultBg({ type: "solid", color: "#04040e" }), defaultEffects({ lightRays: 0.35, rayColor: "#7c6bff", neonGlow: 0.3 }),
    [vis({ name: "Field", style: "particles3d", color1: "#a78bfa", color2: "#38bdf8", y: 0.5, spin: 5 }),
      vis({ name: "Ring", style: "circularWave", color1: "#a78bfa", color2: "#38bdf8", y: 0.5, scale: 0.7, glow: 0.7 }), title({ fontFamily: "Space Grotesk", y: 0.9, fontSize: 46 })]),

  // ------------------------------------------------------------ Electronic
  T("Club Strobe", "Electronic", "Flashing strobe frequency bars with RGB shift.", ["#c026d3", "#22d3ee", "#0a0010"], "Frequency Bars",
    defaultBg({ color: "#080010", color2: "#1c0833", angle: 180 }), defaultEffects({ flash: 0.6, rgb: 0.35, neonGlow: 0.3 }),
    [vis({ name: "Bars", style: "frequencyBars", color1: "#c026d3", color2: "#22d3ee", y: 0.55, bars: 48, thickness: 0.75 }), title({ fontFamily: "Bebas Neue", fontSize: 110, letterSpacing: 12, y: 0.17 }), artist({ y: 0.25 })]),
  T("Bass Drop", "Electronic", "Huge punching ring with flash and motion trails.", ["#ff1744", "#ff9100", "#120000"], "Circular Spectrum",
    defaultBg({ type: "animated", animStyle: "pulse", color: "#0d0000", color2: "#ff1744" }), defaultEffects({ flash: 0.5, motionBlur: 0.35, vignette: 0.5, neonGlow: 0.25 }),
    [vis({ name: "Drop", y: 0.46, scale: 1.0, color1: "#ff9100", color2: "#ff1744", bars: 120, reactiveScale: 0.9, glow: 0.6, thickness: 0.7 }), title({ fontFamily: "Bebas Neue", fontSize: 100, letterSpacing: 10, y: 0.88 })]),
  T("Festival Lights", "Electronic", "Mirrored spectrum under sweeping stage rays.", ["#fb7185", "#818cf8", "#0b0720"], "Mirror Spectrum",
    defaultBg({ type: "animated", animStyle: "aurora", color: "#0b0720", color2: "#6d28d9" }), defaultEffects({ lightRays: 0.7, rayColor: "#fb7185", neonGlow: 0.3 }),
    [vis({ name: "Mirror", style: "mirrorSpectrum", color1: "#fb7185", color2: "#818cf8", y: 0.55, bars: 64, glow: 0.5 }), title({ fontFamily: "Righteous", fontSize: 72, y: 0.16 }), artist({ y: 0.23 })]),

  // ------------------------------------------------------------ Cinematic
  T("Golden Hour", "Cinematic", "Slim gold waveform with film vignette and warm rays.", ["#f5c26b", "#8a5a1f", "#0c0905"], "Audio Waveform",
    defaultBg({ color: "#0e0a06", color2: "#2a1a0a", angle: 200 }), defaultEffects({ vignette: 0.75, lightRays: 0.3, rayColor: "#f5c26b", contrast: 1.1, saturation: 1.1 }),
    [vis({ name: "Gold line", style: "waveform", colorMode: "gradient", color1: "#f5c26b", color2: "#fff1c9", y: 0.5, thickness: 0.28, glow: 0.4 }),
      title({ fontFamily: "Playfair Display", fontSize: 76, y: 0.8, letterSpacing: 4, color: "#f8e3b5" }), artist({ y: 0.88, color: "#f5c26b" })]),
  T("Noir Pulse", "Cinematic", "Monochrome ring, deep shadows and serif titles.", ["#e5e5e5", "#525252", "#050505"], "Circular Waveform",
    defaultBg({ color: "#0a0a0a", color2: "#000000", angle: 180 }), defaultEffects({ vignette: 0.85, saturation: 0, contrast: 1.15 }),
    [vis({ name: "Ring", style: "circularWave", colorMode: "solid", color1: "#e5e5e5", y: 0.46, thickness: 0.3, glow: 0.2 }),
      title({ fontFamily: "Playfair Display", italic: true, fontSize: 68, y: 0.86 }), artist({ y: 0.92 })]),
  T("Deep Space", "Cinematic", "Warp-speed particles around a small spectrum halo.", ["#93c5fd", "#c084fc", "#02030a"], "3D Particles + Ring",
    defaultBg({ type: "animated", animStyle: "stars", color: "#01020a", color2: "#0b1236", angle: 180 }), defaultEffects({ vignette: 0.6, neonGlow: 0.2 }),
    [vis({ name: "Stars", style: "particles3d", color1: "#93c5fd", color2: "#c084fc", y: 0.5, amp: 1.1 }),
      vis({ name: "Halo", style: "circularSpectrum", color1: "#93c5fd", color2: "#c084fc", y: 0.5, scale: 0.7, bars: 80 }),
      title({ fontFamily: "Space Grotesk", y: 0.9, fontSize: 48, letterSpacing: 8 })]),

  // ------------------------------------------------------------ Abstract
  T("Liquid Aura", "Abstract", "Rainbow radial blob that wobbles with the mids.", ["#f472b6", "#60a5fa", "#34d399"], "Radial Spectrum",
    defaultBg({ type: "animated", animStyle: "aurora", color: "#0a0618", color2: "#6d28d9" }), defaultEffects({ waveDistortion: 0.35, neonGlow: 0.3 }),
    [vis({ name: "Aura", style: "radialSpectrum", colorMode: "rainbow", y: 0.46, spin: 10, glow: 0.4 }), title({ fontFamily: "Pacifico", fontSize: 70, y: 0.87 })]),
  T("Prism Shards", "Abstract", "Rainbow combined ring split into RGB shards.", ["#fb7185", "#fbbf24", "#34d399"], "Combined Visualizers",
    defaultBg({ color: "#06060c", color2: "#12121f" }), defaultEffects({ rgb: 0.7, neonGlow: 0.3 }),
    [vis({ name: "Shards", style: "combo", colorMode: "rainbow", y: 0.46, spin: 15, glow: 0.4 }), title({ fontFamily: "Space Grotesk", y: 0.88, fontSize: 52 })]),
  T("Chroma Waves", "Abstract", "Distorted rainbow ribbon with smeared trails.", ["#22d3ee", "#e879f9", "#facc15"], "Symmetrical Waveform",
    defaultBg({ color: "#050510", color2: "#14082e", angle: 160 }), defaultEffects({ waveDistortion: 0.7, motionBlur: 0.45, neonGlow: 0.35 }),
    [vis({ name: "Ribbon", style: "symmetricWave", colorMode: "rainbow", y: 0.5, amp: 1.3, glow: 0.5 }), title({ y: 0.88, fontSize: 52 })]),

  // ------------------------------------------------------------ Lyrics
  T("Lyric Glow", "Lyrics", "Glowing lyric lines over a slim neon spectrum.", ["#a78bfa", "#f0abfc", "#07031a"], "Lyrics + Neon Spectrum",
    defaultBg({ type: "animated", animStyle: "aurora", color: "#07031a", color2: "#5b21b6" }), defaultEffects({ neonGlow: 0.4, vignette: 0.4 }),
    [vis({ name: "Spectrum", style: "neonSpectrum", color1: "#a78bfa", color2: "#f0abfc", y: 0.82, scale: 0.55, bars: 48 }),
      lyr({ name: "Lyrics", y: 0.42, fontFamily: "Space Grotesk", fontSize: 76, glow: 0.8, glowColor: "#a78bfa", showNext: true, transition: "zoom" }), title({ y: 0.1, fontSize: 36, bold: false, letterSpacing: 8 })],
    SAMPLE_LYRICS()),
  T("Karaoke Night", "Lyrics", "Boxed karaoke captions with an equalizer base.", ["#f43f5e", "#fb923c", "#0f0a14"], "Lyrics + Equalizer",
    defaultBg({ color: "#0f0a14", color2: "#2b0f24", angle: 180 }), defaultEffects({ vignette: 0.4 }),
    [vis({ name: "EQ", style: "verticalEq", color1: "#fb923c", color2: "#f43f5e", y: 0.2, scale: 0.55, bars: 36 }),
      lyr({ name: "Lyrics", y: 0.58, fontFamily: "Bebas Neue", fontSize: 110, boxOpacity: 0.55, boxColor: "#000000", showNext: true, transition: "slideUp", letterSpacing: 4 }), title({ y: 0.93, fontSize: 32, bold: false })],
    SAMPLE_LYRICS()),
  T("Poetic Minimal", "Lyrics", "Quiet serif lyrics with a tiny breathing ring.", ["#fafafa", "#a3a3a3", "#0e0e10"], "Lyrics + Waveform Ring",
    defaultBg({ type: "solid", color: "#0e0e10" }), defaultEffects({ vignette: 0.3 }),
    [vis({ name: "Ring", style: "circularWave", colorMode: "solid", color1: "#fafafa", y: 0.25, scale: 0.4, thickness: 0.3, glow: 0 }),
      lyr({ name: "Lyrics", y: 0.62, fontFamily: "Playfair Display", italic: true, bold: false, fontSize: 70, transition: "fade" }), title({ y: 0.92, fontSize: 30, bold: false, letterSpacing: 10 })],
    SAMPLE_LYRICS()),
];

export function getTemplate(id: string) {
  return TEMPLATES.find((t) => t.id === id);
}

export function reId<T extends { id: string }>(layers: T[]): T[] {
  return layers.map((l) => ({ ...deepClone(l), id: uid() }));
}

/** Convert landscape template geometry to portrait / square canvases. */
export function adaptLayers(layers: Layer[], aspect: Aspect): Layer[] {
  if (aspect === "16:9") return layers;
  const f = aspect === "9:16" ? 0.62 : aspect === "1:1" ? 0.8 : 0.7;
  return layers.map((l) => {
    if (l.type !== "visualizer") return l.type === "text" ? { ...l, fontSize: Math.round(l.fontSize * (aspect === "9:16" ? 0.8 : 0.9)) } : { ...l, fontSize: Math.round(l.fontSize * 0.75) };
    const wide = ["linearSpectrum", "verticalEq", "horizontalEq", "waveform", "frequencyBars", "mirrorSpectrum", "symmetricWave", "neonSpectrum", "particles3d"].includes(l.style);
    return wide ? { ...l, scale: l.scale * f } : { ...l, scale: l.scale * (aspect === "9:16" ? 0.85 : 1) };
  });
}

export function defaultProject(name: string, template: Template | null, aspect: Aspect): Project {
  const now = Date.now();
  const t = template ?? getTemplate("circular-1")!;
  const layers = adaptLayers(reId(t.layers), aspect).map((l) => (l.type === "text" && l.kind === "title" ? { ...l, text: name } : l));
  return {
    id: uid(),
    name,
    templateId: t.id,
    createdAt: now,
    updatedAt: now,
    aspect,
    audio: { mediaId: null, demo: true, name: "Built-in demo track", fileDuration: 0, trimStart: 0, trimEnd: 0, volume: 1 },
    background: deepClone(t.background),
    effects: deepClone(t.effects),
    layers,
    lyrics: t.lyrics ? t.lyrics.map((x) => ({ ...x, id: uid() })) : [],
    export: { resolution: 1080, fps: 30, codec: "h264", quality: "high" },
  };
}

export const aspectRatio = (a: Aspect) => ({ "16:9": 16 / 9, "9:16": 9 / 16, "1:1": 1, "4:5": 4 / 5 })[a];

export function canvasSize(a: Aspect, shortSide: number): [number, number] {
  const r = aspectRatio(a);
  let w: number, h: number;
  if (r >= 1) {
    h = shortSide;
    w = Math.round(shortSide * r);
  } else {
    w = shortSide;
    h = Math.round(shortSide / r);
  }
  return [w - (w % 2), h - (h % 2)];
}
