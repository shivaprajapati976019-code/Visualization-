import "@fontsource/inter/latin-400.css";
import "@fontsource/inter/latin-700.css";
import "@fontsource/orbitron/latin-400.css";
import "@fontsource/orbitron/latin-700.css";
import "@fontsource/bebas-neue/latin-400.css";
import "@fontsource/playfair-display/latin-400.css";
import "@fontsource/playfair-display/latin-700.css";
import "@fontsource/playfair-display/latin-400-italic.css";
import "@fontsource/playfair-display/latin-700-italic.css";
import "@fontsource/pacifico/latin-400.css";
import "@fontsource/space-grotesk/latin-400.css";
import "@fontsource/space-grotesk/latin-700.css";
import "@fontsource/righteous/latin-400.css";
import "@fontsource/press-start-2p/latin-400.css";
import "@fontsource/dancing-script/latin-400.css";
import "@fontsource/dancing-script/latin-700.css";
import { FONTS } from "./types";

let p: Promise<void> | null = null;
/** Make sure every bundled font is available to the canvas before first draw. */
export function loadFonts(): Promise<void> {
  if (p) return p;
  p = (async () => {
    try {
      await Promise.all(FONTS.flatMap((f) => [document.fonts.load(`400 40px "${f}"`), document.fonts.load(`700 40px "${f}"`), document.fonts.load(`italic 400 40px "${f}"`)]));
    } catch {
      /* fonts will fall back */
    }
  })();
  return p;
}
