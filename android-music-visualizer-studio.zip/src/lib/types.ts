export type VisStyle =
  | "circularSpectrum"
  | "circularWave"
  | "linearSpectrum"
  | "verticalEq"
  | "horizontalEq"
  | "waveform"
  | "radialSpectrum"
  | "frequencyBars"
  | "particles"
  | "neonSpectrum"
  | "mirrorSpectrum"
  | "symmetricWave"
  | "particles3d"
  | "combo";

export const VIS_STYLES: { id: VisStyle; label: string }[] = [
  { id: "circularSpectrum", label: "Circular Spectrum" },
  { id: "circularWave", label: "Circular Waveform" },
  { id: "linearSpectrum", label: "Linear Spectrum" },
  { id: "verticalEq", label: "Vertical Equalizer" },
  { id: "horizontalEq", label: "Horizontal Equalizer" },
  { id: "waveform", label: "Audio Waveform" },
  { id: "radialSpectrum", label: "Radial Spectrum" },
  { id: "frequencyBars", label: "Frequency Bars" },
  { id: "particles", label: "Reactive Particles" },
  { id: "neonSpectrum", label: "Neon Spectrum" },
  { id: "mirrorSpectrum", label: "Mirror Spectrum" },
  { id: "symmetricWave", label: "Symmetrical Waveform" },
  { id: "particles3d", label: "3D Particle Field" },
  { id: "combo", label: "Combined (Ring + Wave + Core)" },
];

export type ColorMode = "solid" | "gradient" | "rainbow";

export interface BaseLayer {
  id: string;
  name: string;
  visible: boolean;
  x: number; // 0..1 of canvas width
  y: number; // 0..1 of canvas height
  scale: number;
  rotation: number; // degrees
  opacity: number; // 0..1
  start: number; // timeline seconds
  end: number; // timeline seconds, 0 = until the end
}

export interface VisualizerLayer extends BaseLayer {
  type: "visualizer";
  style: VisStyle;
  colorMode: ColorMode;
  color1: string;
  color2: string;
  bars: number;
  thickness: number; // 0.1 .. 1
  amp: number; // sensitivity
  smoothing: number; // 0..1
  rounded: boolean;
  glow: number; // 0..1
  spin: number; // deg / sec
  inner: number; // inner radius ratio for circular styles
  reactiveScale: number; // pulse with bass 0..1
}

export type TextAnim =
  | "none"
  | "fade"
  | "slideUp"
  | "typewriter"
  | "pulse"
  | "bounce"
  | "float"
  | "zoom";

export interface TextStyle {
  text: string;
  fontFamily: string;
  fontSize: number;
  bold: boolean;
  italic: boolean;
  color: string;
  gradient: boolean;
  color2: string;
  letterSpacing: number;
  align: "left" | "center" | "right";
  shadow: number; // 0..1
  shadowColor: string;
  outline: number; // px
  outlineColor: string;
  glow: number; // 0..1
  glowColor: string;
  anim: TextAnim;
}

export interface TextLayer extends BaseLayer, TextStyle {
  type: "text";
  kind: "title" | "artist" | "album" | "custom" | "info";
}

export interface LyricLine {
  id: string;
  start: number;
  end: number;
  text: string;
}

export interface LyricsLayer extends BaseLayer, TextStyle {
  type: "lyrics";
  transition: "none" | "fade" | "slideUp" | "zoom" | "typewriter";
  boxColor: string;
  boxOpacity: number;
  showNext: boolean;
}

export type Layer = VisualizerLayer | TextLayer | LyricsLayer;

export type BgType = "solid" | "gradient" | "image" | "video" | "animated";

export interface Background {
  type: BgType;
  color: string;
  color2: string;
  angle: number;
  animStyle: "aurora" | "pulse" | "stars" | "grid";
  mediaId: string | null;
  mediaName: string;
  blur: number; // px at 1080
  opacity: number;
  scale: number; // zoom / crop
  offsetX: number; // -1..1
  offsetY: number; // -1..1
  fit: "cover" | "contain";
  dim: number; // dark overlay 0..1
  reactiveZoom: number; // 0..1
}

export interface Effects {
  neonGlow: number;
  rgb: number;
  glitch: number;
  blur: number;
  motionBlur: number;
  lightRays: number;
  particles: number;
  waveDistortion: number;
  flash: number;
  vignette: number;
  brightness: number; // 1 = neutral
  contrast: number;
  saturation: number;
  hue: number;
  rayColor: string;
  particleColor: string;
}

export interface AudioSettings {
  mediaId: string | null; // null + demo => demo track
  demo: boolean;
  name: string;
  fileDuration: number;
  trimStart: number;
  trimEnd: number;
  volume: number;
}

export type Aspect = "16:9" | "9:16" | "1:1" | "4:5";

export interface ExportSettings {
  resolution: 720 | 1080 | 1440 | 2160;
  fps: 24 | 30 | 60;
  codec: "h264" | "h265";
  quality: "standard" | "high" | "max";
}

export interface Project {
  id: string;
  name: string;
  templateId: string;
  createdAt: number;
  updatedAt: number;
  aspect: Aspect;
  audio: AudioSettings;
  background: Background;
  effects: Effects;
  layers: Layer[];
  lyrics: LyricLine[];
  export: ExportSettings;
  thumbnail?: string;
}

export interface SavedDesign {
  id: string;
  name: string;
  createdAt: number;
  thumbnail?: string;
  templateId: string;
  background: Background;
  effects: Effects;
  layers: Layer[];
}

export interface MediaRecord {
  id: string;
  kind: "audio" | "image" | "video";
  name: string;
  type: string;
  size: number;
  blob: Blob;
  createdAt: number;
}

export const TEMPLATE_CATEGORIES = [
  "Circular",
  "Spectrum",
  "Waveform",
  "Equalizer",
  "Particle",
  "Neon",
  "Minimal",
  "Futuristic",
  "Electronic",
  "Cinematic",
  "Abstract",
  "Lyrics",
] as const;
export type TemplateCategory = (typeof TEMPLATE_CATEGORIES)[number];

export interface Template {
  id: string;
  name: string;
  category: TemplateCategory;
  description: string;
  palette: string[];
  styleLabel: string;
  background: Background;
  effects: Effects;
  layers: Layer[];
  lyrics?: LyricLine[];
}

export const FONTS = [
  "Inter",
  "Orbitron",
  "Bebas Neue",
  "Playfair Display",
  "Pacifico",
  "Space Grotesk",
  "Righteous",
  "Press Start 2P",
  "Dancing Script",
];
