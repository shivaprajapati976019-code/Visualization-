import { decodeAudio, getDemoTrack } from "./audio";
import { db } from "./db";
import { getSettings } from "./settings";
import { defaultProject, getTemplate, reId } from "./templates";
import type { Aspect, AudioSettings, Project, SavedDesign, Template } from "./types";
import { deepClone, uid } from "./util";

export const DEMO_DURATION = (16 * 4 * 60) / 124;

const bufCache = new Map<string, AudioBuffer>();

export async function audioFromFile(file: File): Promise<{ audio: AudioSettings; buffer: AudioBuffer }> {
  const data = await file.arrayBuffer();
  let buffer: AudioBuffer;
  try {
    buffer = await decodeAudio(data.slice(0));
  } catch {
    throw new Error(`"${file.name}" could not be decoded. This device may not support that codec — try MP3, WAV, M4A/AAC or FLAC.`);
  }
  const rec = await db.addMedia(file, "audio");
  bufCache.set(rec.id, buffer);
  return {
    audio: { mediaId: rec.id, demo: false, name: file.name, fileDuration: buffer.duration, trimStart: 0, trimEnd: buffer.duration, volume: 1 },
    buffer,
  };
}

export async function getProjectAudio(p: Project): Promise<AudioBuffer | null> {
  if (p.audio.demo || !p.audio.mediaId) return getDemoTrack();
  const hit = bufCache.get(p.audio.mediaId);
  if (hit) return hit;
  const rec = await db.getMedia(p.audio.mediaId);
  if (!rec) return null;
  const buf = await decodeAudio(await rec.blob.arrayBuffer());
  if (bufCache.size > 2) bufCache.delete(bufCache.keys().next().value!);
  bufCache.set(p.audio.mediaId, buf);
  return buf;
}

export interface NewProjectOptions {
  name: string;
  template: Template | null;
  aspect: Aspect;
  audioFile?: File | null;
  bgFile?: File | null;
  design?: SavedDesign | null;
}

export async function createProject(o: NewProjectOptions): Promise<Project> {
  const s = getSettings();
  const p = defaultProject(o.name, o.template, o.aspect);
  p.export = { resolution: s.defaultResolution, fps: s.defaultFps, codec: s.defaultCodec, quality: s.renderQuality };
  p.audio.fileDuration = DEMO_DURATION;
  p.audio.trimEnd = DEMO_DURATION;
  if (o.design) {
    p.layers = reId(deepClone(o.design.layers));
    p.background = deepClone(o.design.background);
    p.effects = deepClone(o.design.effects);
    p.templateId = o.design.templateId;
  }
  if (o.audioFile) {
    const { audio } = await audioFromFile(o.audioFile);
    p.audio = audio;
  }
  if (o.bgFile) {
    const kind = o.bgFile.type.startsWith("video") ? "video" : "image";
    const rec = await db.addMedia(o.bgFile, kind);
    p.background = { ...p.background, type: kind, mediaId: rec.id, mediaName: rec.name };
  }
  await db.putProject(p);
  return p;
}

export async function duplicateProject(id: string): Promise<Project | null> {
  const p = await db.getProject(id);
  if (!p) return null;
  const copy: Project = { ...deepClone(p), id: uid(), name: p.name + " copy", createdAt: Date.now(), updatedAt: Date.now() };
  copy.layers = reId(copy.layers);
  await db.putProject(copy);
  return copy;
}

export async function removeProject(id: string) {
  await db.deleteProject(id);
  await db.cleanOrphanMedia();
}

export function templateOf(p: Project) {
  return getTemplate(p.templateId);
}
