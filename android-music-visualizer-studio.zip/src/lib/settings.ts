import { useSyncExternalStore } from "react";
import type { ExportSettings } from "./types";

export interface AppSettings {
  accent: "violet" | "cyan" | "pink" | "lime" | "orange";
  amoled: boolean;
  defaultResolution: ExportSettings["resolution"];
  defaultFps: ExportSettings["fps"];
  defaultCodec: ExportSettings["codec"];
  renderQuality: ExportSettings["quality"];
  previewQuality: "low" | "medium" | "high";
  autosave: boolean;
}

export const ACCENTS: Record<AppSettings["accent"], [string, string]> = {
  violet: ["#8b5cf6", "#d946ef"],
  cyan: ["#06b6d4", "#3b82f6"],
  pink: ["#ec4899", "#f97316"],
  lime: ["#84cc16", "#10b981"],
  orange: ["#f97316", "#facc15"],
};

const KEY = "ovs-settings-v1";
const defaults: AppSettings = {
  accent: "violet",
  amoled: false,
  defaultResolution: 1080,
  defaultFps: 30,
  defaultCodec: "h264",
  renderQuality: "high",
  previewQuality: "medium",
  autosave: true,
};

let cache: AppSettings = (() => {
  try {
    return { ...defaults, ...JSON.parse(localStorage.getItem(KEY) || "{}") };
  } catch {
    return defaults;
  }
})();
const listeners = new Set<() => void>();

export function applyTheme(s: AppSettings = cache) {
  const [a, b] = ACCENTS[s.accent];
  const r = document.documentElement;
  r.style.setProperty("--accent", a);
  r.style.setProperty("--accent2", b);
  r.classList.toggle("amoled", s.amoled);
}

export function setSettings(p: Partial<AppSettings>) {
  cache = { ...cache, ...p };
  localStorage.setItem(KEY, JSON.stringify(cache));
  applyTheme(cache);
  listeners.forEach((l) => l());
}

export const getSettings = () => cache;

export function useSettings(): AppSettings {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => cache
  );
}

export const PREVIEW_SIDE = { low: 360, medium: 540, high: 720 };
