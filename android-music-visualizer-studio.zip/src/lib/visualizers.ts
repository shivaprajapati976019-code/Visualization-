import { BANDS, type AudioFrame } from "./audio";
import type { VisualizerLayer } from "./types";
import { lerp, mixColor, mulberry32, rgba } from "./util";

interface Part {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  c: number;
}
interface Star {
  x: number;
  y: number;
  z: number;
  c: number;
}

export interface LayerState {
  arrays: Record<string, Float32Array>;
  parts: Part[];
  stars: Star[] | null;
  acc: number;
  rng: () => number;
  rot: number;
}

export function newLayerState(seed: number): LayerState {
  return { arrays: {}, parts: [], stars: null, acc: 0, rng: mulberry32(seed), rot: 0 };
}

export interface V {
  ctx: CanvasRenderingContext2D;
  L: VisualizerLayer;
  S: LayerState;
  f: AudioFrame;
  dt: number;
  t: number;
  beat: number;
  k: number; // pixel factor (unit * layer scale) for shadow blur
}

export interface Extent {
  w: number;
  h: number;
}

const TAU = Math.PI * 2;

function arr(S: LayerState, key: string, n: number) {
  let a = S.arrays[key];
  if (!a || a.length !== n) a = S.arrays[key] = new Float32Array(n);
  return a;
}

function getBars(V: V, count: number, key = "m"): Float32Array {
  const { L, S, f, dt } = V;
  const sm = arr(S, key, count);
  const out = arr(S, key + "_o", count);
  const per = BANDS / count;
  for (let i = 0; i < count; i++) {
    const a = Math.floor(i * per);
    const b = Math.max(a + 1, Math.floor((i + 1) * per));
    let mx = 0;
    for (let k = a; k < b && k < BANDS; k++) if (f.bands[k] > mx) mx = f.bands[k];
    const target = mx * L.amp;
    const rate = target > sm[i] ? lerp(90, 16, L.smoothing) : lerp(34, 3.5, L.smoothing);
    sm[i] += (target - sm[i]) * (1 - Math.exp(-rate * dt));
    out[i] = sm[i];
  }
  return out;
}

function peaks(V: V, bars: Float32Array, key: string) {
  const p = arr(V.S, key, bars.length);
  for (let i = 0; i < bars.length; i++) p[i] = Math.max(bars[i], p[i] - V.dt * 0.4);
  return p;
}

function colorAt(L: VisualizerLayer, i: number, n: number): string {
  if (L.colorMode === "solid") return L.color1;
  const k = n > 1 ? i / (n - 1) : 0;
  if (L.colorMode === "gradient") return mixColor(L.color1, L.color2, k);
  return `hsl(${Math.round(k * 300)},90%,62%)`;
}

function addStops(g: CanvasGradient, L: VisualizerLayer, reverse = false) {
  const a = reverse ? L.color2 : L.color1;
  const b = reverse ? L.color1 : L.color2;
  if (L.colorMode === "solid") {
    g.addColorStop(0, L.color1);
    g.addColorStop(1, L.color1);
  } else if (L.colorMode === "gradient") {
    g.addColorStop(0, a);
    g.addColorStop(1, b);
  } else {
    for (let i = 0; i <= 5; i++) g.addColorStop(i / 5, `hsl(${i * 60},90%,62%)`);
  }
}

function linPaint(V: V, x0: number, y0: number, x1: number, y1: number, reverse = false) {
  const g = V.ctx.createLinearGradient(x0, y0, x1, y1);
  addStops(g, V.L, reverse);
  return g;
}

function glow(V: V, amount = V.L.glow) {
  if (amount > 0) {
    V.ctx.shadowColor = V.L.colorMode === "solid" ? V.L.color1 : V.L.color2;
    V.ctx.shadowBlur = amount * 38 * V.k;
  }
}
function noGlow(ctx: CanvasRenderingContext2D) {
  ctx.shadowBlur = 0;
  ctx.shadowColor = "transparent";
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function smoothPath(ctx: CanvasRenderingContext2D, pts: [number, number][], close = false) {
  const n = pts.length;
  if (n < 2) return;
  if (close) {
    const mx = (pts[n - 1][0] + pts[0][0]) / 2;
    const my = (pts[n - 1][1] + pts[0][1]) / 2;
    ctx.moveTo(mx, my);
    for (let i = 0; i < n; i++) {
      const p = pts[i];
      const q = pts[(i + 1) % n];
      ctx.quadraticCurveTo(p[0], p[1], (p[0] + q[0]) / 2, (p[1] + q[1]) / 2);
    }
    ctx.closePath();
  } else {
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < n - 1; i++) {
      const p = pts[i];
      const q = pts[i + 1];
      ctx.quadraticCurveTo(p[0], p[1], (p[0] + q[0]) / 2, (p[1] + q[1]) / 2);
    }
    ctx.lineTo(pts[n - 1][0], pts[n - 1][1]);
  }
}

// ---------------------------------------------------------------- circular

function circularSpectrum(V: V, radiusMul = 1, key = "c"): Extent {
  const { ctx, L, S } = V;
  const n = Math.max(8, Math.round(L.bars / 2) * 2);
  const half = n / 2;
  const bars = getBars(V, half, key);
  const r = 200 * L.inner * radiusMul;
  const lw = Math.max(2, ((TAU * r) / n) * L.thickness * 0.9);
  const a0 = (S.rot * Math.PI) / 180 + Math.PI / 2;
  ctx.lineWidth = lw;
  ctx.lineCap = L.rounded ? "round" : "butt";
  glow(V);
  for (let i = 0; i < n; i++) {
    const idx = i < half ? i : n - 1 - i;
    const len = 6 + bars[idx] * 170 * radiusMul;
    const a = (i / n) * TAU + a0;
    const c = Math.cos(a),
      s = Math.sin(a);
    ctx.strokeStyle = colorAt(L, idx, half);
    ctx.beginPath();
    ctx.moveTo(c * r, s * r);
    ctx.lineTo(c * (r + len), s * (r + len));
    ctx.stroke();
  }
  noGlow(ctx);
  ctx.globalAlpha *= 0.35;
  ctx.lineWidth = 2;
  ctx.strokeStyle = L.color1;
  ctx.beginPath();
  ctx.arc(0, 0, r - 10, 0, TAU);
  ctx.stroke();
  ctx.globalAlpha /= 0.35;
  const e = (r + 200) * 2;
  return { w: e, h: e };
}

function ringPaint(V: V, r: number): string | CanvasGradient {
  const { ctx, L } = V;
  if (L.colorMode === "solid" || typeof ctx.createConicGradient !== "function") return L.color1;
  const g = ctx.createConicGradient((V.S.rot * Math.PI) / 180, 0, 0);
  if (L.colorMode === "gradient") {
    g.addColorStop(0, L.color1);
    g.addColorStop(0.5, L.color2);
    g.addColorStop(1, L.color1);
  } else for (let i = 0; i <= 6; i++) g.addColorStop(i / 6, `hsl(${i * 60},90%,62%)`);
  void r;
  return g;
}

function circularWave(V: V, radiusMul = 1, ampMul = 1): Extent {
  const { ctx, L, f } = V;
  const r = 200 * L.inner * radiusMul;
  const pts = 256;
  const w = f.wave;
  const diff = w[511] - w[0];
  const path: [number, number][] = [];
  for (let i = 0; i < pts; i++) {
    const idx = i * 2;
    const v = w[idx] - (diff * idx) / 511;
    const a = (i / pts) * TAU - Math.PI / 2 + (V.S.rot * Math.PI) / 180;
    const rad = r + v * L.amp * 300 * ampMul;
    path.push([Math.cos(a) * rad, Math.sin(a) * rad]);
  }
  ctx.lineJoin = "round";
  ctx.beginPath();
  smoothPath(ctx, path, true);
  ctx.fillStyle = rgba(L.color1, 0.08);
  ctx.fill();
  glow(V);
  ctx.strokeStyle = ringPaint(V, r);
  ctx.lineWidth = Math.max(1.5, 8 * L.thickness);
  ctx.stroke();
  noGlow(ctx);
  ctx.globalAlpha *= 0.4;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.82, 0, TAU);
  ctx.stroke();
  ctx.globalAlpha /= 0.4;
  const e = (r + 300) * 2;
  return { w: e, h: e };
}

function radialSpectrum(V: V): Extent {
  const { ctx, L } = V;
  const n = Math.max(16, Math.round(L.bars / 2) * 2);
  const half = n / 2;
  const bars = getBars(V, half, "r");
  const r = 190 * L.inner;
  const path: [number, number][] = [];
  const a0 = (V.S.rot * Math.PI) / 180 + Math.PI / 2;
  for (let i = 0; i < n; i++) {
    const idx = i < half ? i : n - 1 - i;
    const a = (i / n) * TAU + a0;
    const rad = r + 4 + bars[idx] * 190;
    path.push([Math.cos(a) * rad, Math.sin(a) * rad]);
  }
  const g = ctx.createRadialGradient(0, 0, r * 0.4, 0, 0, r + 200);
  g.addColorStop(0, rgba(L.color1, 0.05));
  g.addColorStop(1, rgba(L.colorMode === "solid" ? L.color1 : L.color2, 0.6));
  ctx.beginPath();
  smoothPath(ctx, path, true);
  ctx.fillStyle = g;
  ctx.fill();
  glow(V);
  ctx.lineWidth = Math.max(2, 6 * L.thickness);
  ctx.lineJoin = "round";
  ctx.strokeStyle = ringPaint(V, r);
  ctx.stroke();
  noGlow(ctx);
  ctx.beginPath();
  ctx.arc(0, 0, r - 8, 0, TAU);
  ctx.lineWidth = 3;
  ctx.strokeStyle = rgba(L.color1, 0.7);
  ctx.stroke();
  const e = (r + 220) * 2;
  return { w: e, h: e };
}

// ---------------------------------------------------------------- linear

const LW = 1400;

function drawBar(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, rounded: boolean) {
  if (rounded && w > 3) {
    rr(ctx, x, y, w, h, w / 2);
    ctx.fill();
  } else ctx.fillRect(x, y, w, h);
}

function linearSpectrum(V: V): Extent {
  const { ctx, L } = V;
  const n = L.bars;
  const bars = getBars(V, n, "l");
  const bw = LW / n;
  const w = Math.max(2, bw * L.thickness);
  const base = 150;
  ctx.fillStyle = linPaint(V, -LW / 2, 0, LW / 2, 0);
  glow(V);
  for (let i = 0; i < n; i++) {
    const h = 5 + bars[i] * 300;
    drawBar(ctx, -LW / 2 + i * bw + (bw - w) / 2, base - h, w, h, L.rounded);
  }
  noGlow(ctx);
  return { w: LW, h: 320 };
}

function frequencyBars(V: V): Extent {
  const { ctx, L } = V;
  const n = L.bars;
  const bars = getBars(V, n, "fb");
  const pk = peaks(V, bars, "fb_p");
  const bw = LW / n;
  const w = Math.max(2, bw * L.thickness);
  const base = 40;
  glow(V);
  for (let i = 0; i < n; i++) {
    const x = -LW / 2 + i * bw + (bw - w) / 2;
    const h = 6 + bars[i] * 270;
    ctx.fillStyle = colorAt(L, i, n);
    drawBar(ctx, x, base - h, w, h, L.rounded);
    // peak cap
    ctx.fillRect(x, base - (8 + pk[i] * 270) - w * 0.9, w, Math.max(2, w * 0.4));
  }
  noGlow(ctx);
  // reflection
  ctx.save();
  ctx.globalAlpha *= 0.22;
  for (let i = 0; i < n; i++) {
    const x = -LW / 2 + i * bw + (bw - w) / 2;
    const h = (6 + bars[i] * 270) * 0.4;
    ctx.fillStyle = colorAt(L, i, n);
    drawBar(ctx, x, base + 12, w, h, L.rounded);
  }
  ctx.restore();
  return { w: LW, h: 420 };
}

function verticalEq(V: V): Extent {
  const { ctx, L } = V;
  const cols = Math.min(L.bars, 48);
  const bars = getBars(V, cols, "ve");
  const pk = peaks(V, bars, "ve_p");
  const segs = 16;
  const W = 1200;
  const H = 340;
  const cw = W / cols;
  const w = Math.max(3, cw * L.thickness);
  const sh = H / segs;
  glow(V);
  for (let i = 0; i < cols; i++) {
    const x = -W / 2 + i * cw + (cw - w) / 2;
    const lit = Math.min(segs, Math.round(bars[i] * segs * 0.95));
    for (let s = 0; s < segs; s++) {
      const k = s / (segs - 1);
      const y = H / 2 - (s + 1) * sh + sh * 0.14;
      ctx.fillStyle = s < lit ? (L.colorMode === "rainbow" ? `hsl(${(1 - k) * 140},90%,58%)` : mixColor(L.color1, L.color2, k)) : "rgba(255,255,255,0.06)";
      if (L.rounded) {
        rr(ctx, x, y, w, sh * 0.72, 3);
        ctx.fill();
      } else ctx.fillRect(x, y, w, sh * 0.72);
    }
    const ps = Math.min(segs - 1, Math.round(pk[i] * segs * 0.95));
    if (ps > lit) {
      ctx.fillStyle = "#fff";
      ctx.fillRect(x, H / 2 - (ps + 1) * sh + sh * 0.14, w, sh * 0.35);
    }
  }
  noGlow(ctx);
  return { w: W, h: H };
}

function horizontalEq(V: V): Extent {
  const { ctx, L } = V;
  const rows = Math.min(Math.max(8, Math.round(L.bars / 4)), 28);
  const bars = getBars(V, rows, "he");
  const W = 900;
  const H = 520;
  const rh = H / rows;
  const h = Math.max(3, rh * L.thickness * 0.85);
  const segW = 22;
  glow(V);
  for (let i = 0; i < rows; i++) {
    const y = H / 2 - (i + 1) * rh + (rh - h) / 2;
    const len = Math.max(segW, bars[i] * W);
    const segs = Math.floor(len / segW);
    for (let s = 0; s < segs; s++) {
      ctx.fillStyle = L.colorMode === "rainbow" ? `hsl(${(i / rows) * 300},90%,60%)` : mixColor(L.color1, L.color2, s / (W / segW));
      ctx.fillRect(-W / 2 + s * segW, y, segW - 4, h);
    }
  }
  noGlow(ctx);
  return { w: W, h: H };
}

function waveform(V: V): Extent {
  const { ctx, L, f } = V;
  const pts = 256;
  const path: [number, number][] = [];
  for (let i = 0; i < pts; i++) {
    const v = f.wave[Math.min(511, i * 2)];
    path.push([-LW / 2 + (i / (pts - 1)) * LW, v * L.amp * 360]);
  }
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.beginPath();
  smoothPath(ctx, path);
  glow(V);
  ctx.strokeStyle = linPaint(V, -LW / 2, 0, LW / 2, 0);
  ctx.lineWidth = Math.max(1.5, 9 * L.thickness);
  ctx.stroke();
  noGlow(ctx);
  ctx.globalAlpha *= 0.25;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-LW / 2, 0);
  ctx.lineTo(LW / 2, 0);
  ctx.stroke();
  ctx.globalAlpha /= 0.25;
  return { w: LW, h: 380 };
}

function mirrorSpectrum(V: V): Extent {
  const { ctx, L } = V;
  const n = L.bars;
  const bars = getBars(V, n, "mi");
  const bw = LW / n;
  const w = Math.max(2, bw * L.thickness);
  ctx.fillStyle = linPaint(V, -LW / 2, 0, LW / 2, 0);
  glow(V);
  for (let i = 0; i < n; i++) {
    const h = 4 + bars[i] * 170;
    drawBar(ctx, -LW / 2 + i * bw + (bw - w) / 2, -h, w, h * 2, L.rounded);
  }
  noGlow(ctx);
  return { w: LW, h: 380 };
}

function symmetricWave(V: V): Extent {
  const { ctx, L, f } = V;
  const pts = 128;
  const top: [number, number][] = [];
  const bot: [number, number][] = [];
  for (let i = 0; i < pts; i++) {
    let m = 0;
    for (let k = 0; k < 4; k++) m = Math.max(m, Math.abs(f.wave[Math.min(511, i * 4 + k)]));
    const edge = Math.sin((i / (pts - 1)) * Math.PI);
    const h = (3 + m * L.amp * 420) * (0.25 + 0.75 * edge);
    const x = -LW / 2 + (i / (pts - 1)) * LW;
    top.push([x, -h]);
    bot.push([x, h]);
  }
  ctx.beginPath();
  smoothPath(ctx, top);
  const rb = bot.slice().reverse();
  ctx.lineTo(rb[0][0], rb[0][1]);
  smoothPath(ctx, rb);
  ctx.closePath();
  const g = ctx.createLinearGradient(0, -300, 0, 300);
  g.addColorStop(0, rgba(L.color1, 0.9));
  g.addColorStop(0.5, rgba(L.colorMode === "solid" ? L.color1 : L.color2, 0.35));
  g.addColorStop(1, rgba(L.color1, 0.9));
  ctx.fillStyle = g;
  glow(V);
  ctx.fill();
  noGlow(ctx);
  ctx.lineWidth = Math.max(1.5, 5 * L.thickness);
  ctx.strokeStyle = linPaint(V, -LW / 2, 0, LW / 2, 0);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-LW / 2, 0);
  ctx.lineTo(LW / 2, 0);
  ctx.lineWidth = 2;
  ctx.stroke();
  return { w: LW, h: 460 };
}

function neonSpectrum(V: V): Extent {
  const { ctx, L } = V;
  const n = Math.max(16, Math.min(96, L.bars));
  const bars = getBars(V, n, "ne");
  const top: [number, number][] = [];
  const bot: [number, number][] = [];
  for (let i = 0; i < n; i++) {
    // low frequencies in the centre, symmetric
    const x = -LW / 2 + (i / (n - 1)) * LW;
    const idx = Math.round(Math.abs(i / (n - 1) - 0.5) * 2 * (n - 1));
    const taper = 0.35 + 0.65 * Math.sin((i / (n - 1)) * Math.PI);
    const h = (2 + bars[Math.min(n - 1, n - 1 - idx)] * 230) * taper;
    top.push([x, -h]);
    bot.push([x, h]);
  }
  const passes: [number, number, number][] = [
    [26, 0.14, 1],
    [12, 0.35, 0.8],
    [4, 1, 0.6],
  ];
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  for (const [w, a, gl] of passes) {
    ctx.globalAlpha *= a;
    ctx.lineWidth = w * (0.5 + L.thickness);
    ctx.strokeStyle = linPaint(V, -LW / 2, 0, LW / 2, 0);
    ctx.shadowColor = L.colorMode === "solid" ? L.color1 : L.color2;
    ctx.shadowBlur = (20 + L.glow * 40) * V.k * gl;
    for (const p of [top, bot]) {
      ctx.beginPath();
      smoothPath(ctx, p);
      ctx.stroke();
    }
    ctx.globalAlpha /= a;
  }
  noGlow(ctx);
  ctx.strokeStyle = "rgba(255,255,255,0.9)";
  ctx.lineWidth = 1.5;
  for (const p of [top, bot]) {
    ctx.beginPath();
    smoothPath(ctx, p);
    ctx.stroke();
  }
  return { w: LW, h: 420 };
}

// ---------------------------------------------------------------- particles

function particles(V: V): Extent {
  const { ctx, L, S, f, dt } = V;
  const parts = S.parts;
  S.acc += (f.bass * 70 + V.beat * 200 + f.level * 40) * dt * L.amp;
  while (S.acc >= 1 && parts.length < 800) {
    S.acc -= 1;
    const a = S.rng() * TAU;
    const sp = (70 + S.rng() * 280) * (0.5 + f.mid + V.beat);
    const r0 = 90 * L.inner;
    parts.push({
      x: Math.cos(a) * r0,
      y: Math.sin(a) * r0,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: 0,
      max: 1.1 + S.rng() * 1.6,
      size: (1.5 + S.rng() * 4.5) * (0.5 + L.thickness * 1.5),
      c: S.rng(),
    });
  }
  S.acc = Math.min(S.acc, 5);
  const base = ctx.globalAlpha;
  glow(V);
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i];
    p.life += dt;
    if (p.life >= p.max) {
      parts.splice(i, 1);
      continue;
    }
    const drag = Math.exp(-0.5 * dt);
    p.vx *= drag;
    p.vy *= drag;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    const k = 1 - p.life / p.max;
    ctx.globalAlpha = base * k;
    ctx.fillStyle = colorAt(L, Math.floor(p.c * 12), 12);
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size * (0.4 + k * 0.8), 0, TAU);
    ctx.fill();
  }
  ctx.globalAlpha = base;
  // reactive ring of dots
  const n = 48;
  const bars = getBars(V, n / 2, "pr");
  for (let i = 0; i < n; i++) {
    const idx = i < n / 2 ? i : n - 1 - i;
    const a = (i / n) * TAU + (S.rot * Math.PI) / 180;
    const rad = 90 * L.inner + bars[idx] * 60;
    ctx.fillStyle = colorAt(L, idx, n / 2);
    ctx.beginPath();
    ctx.arc(Math.cos(a) * rad, Math.sin(a) * rad, 3 + bars[idx] * 7 * (0.5 + L.thickness), 0, TAU);
    ctx.fill();
  }
  noGlow(ctx);
  return { w: 700, h: 700 };
}

function particles3d(V: V): Extent {
  const { ctx, L, S, f, dt } = V;
  if (!S.stars) {
    S.stars = [];
    for (let i = 0; i < 380; i++)
      S.stars.push({ x: (S.rng() * 2 - 1) * 1.6, y: (S.rng() * 2 - 1) * 1.1, z: 0.04 + S.rng() * 0.96, c: S.rng() });
  }
  const speed = (0.12 + f.level * 0.8 + V.beat * 0.6 + f.bass * 0.5) * L.amp;
  const F = 420;
  ctx.rotate((S.rot * Math.PI) / 180);
  glow(V);
  ctx.lineCap = "round";
  for (const s of S.stars) {
    const pz = s.z + speed * dt * 4;
    s.z -= speed * dt;
    if (s.z < 0.03) {
      s.x = (S.rng() * 2 - 1) * 1.6;
      s.y = (S.rng() * 2 - 1) * 1.1;
      s.z = 1;
      continue;
    }
    const sx = (s.x / s.z) * F * 0.5;
    const sy = (s.y / s.z) * F * 0.5;
    if (Math.abs(sx) > 900 || Math.abs(sy) > 640) {
      s.x = (S.rng() * 2 - 1) * 1.6;
      s.y = (S.rng() * 2 - 1) * 1.1;
      s.z = 1;
      continue;
    }
    const px = (s.x / pz) * F * 0.5;
    const py = (s.y / pz) * F * 0.5;
    const near = 1 - s.z;
    ctx.globalAlpha = Math.min(1, 0.15 + near * 1.3);
    ctx.strokeStyle = colorAt(L, Math.floor(s.c * 12), 12);
    ctx.lineWidth = (1 + near * 7) * (0.4 + L.thickness * 1.2);
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(sx, sy);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  noGlow(ctx);
  return { w: 1800, h: 1280 };
}

function combo(V: V): Extent {
  const { ctx, L, f } = V;
  circularSpectrum(V, 1, "cb");
  circularWave(V, 0.62, 0.45);
  // pulsing core
  const cr = 55 * L.inner * (1 + f.bass * 0.7 + V.beat * 0.25);
  const g = ctx.createRadialGradient(0, 0, 0, 0, 0, cr);
  g.addColorStop(0, "rgba(255,255,255,0.95)");
  g.addColorStop(0.35, rgba(L.color1, 0.9));
  g.addColorStop(1, rgba(L.colorMode === "solid" ? L.color1 : L.color2, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, cr, 0, TAU);
  ctx.fill();
  // outer rotating dashed ring
  ctx.save();
  ctx.rotate((-V.S.rot * Math.PI) / 90);
  ctx.setLineDash([8, 22]);
  ctx.lineWidth = 3;
  ctx.globalAlpha *= 0.55;
  ctx.strokeStyle = L.colorMode === "solid" ? L.color1 : L.color2;
  ctx.beginPath();
  ctx.arc(0, 0, 200 * L.inner + 215, 0, TAU);
  ctx.stroke();
  ctx.restore();
  const e = (200 * L.inner + 240) * 2;
  return { w: e, h: e };
}

export function drawVisualizer(V: V): Extent {
  switch (V.L.style) {
    case "circularSpectrum":
      return circularSpectrum(V);
    case "circularWave":
      return circularWave(V);
    case "linearSpectrum":
      return linearSpectrum(V);
    case "verticalEq":
      return verticalEq(V);
    case "horizontalEq":
      return horizontalEq(V);
    case "waveform":
      return waveform(V);
    case "radialSpectrum":
      return radialSpectrum(V);
    case "frequencyBars":
      return frequencyBars(V);
    case "particles":
      return particles(V);
    case "neonSpectrum":
      return neonSpectrum(V);
    case "mirrorSpectrum":
      return mirrorSpectrum(V);
    case "symmetricWave":
      return symmetricWave(V);
    case "particles3d":
      return particles3d(V);
    case "combo":
      return combo(V);
  }
}
