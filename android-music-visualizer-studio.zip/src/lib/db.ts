import type { MediaRecord, Project, SavedDesign } from "./types";
import { uid } from "./util";

const DB_NAME = "offline-visualizer-studio";
const VERSION = 1;
let dbp: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("projects")) db.createObjectStore("projects", { keyPath: "id" });
      if (!db.objectStoreNames.contains("media")) db.createObjectStore("media", { keyPath: "id" });
      if (!db.objectStoreNames.contains("designs")) db.createObjectStore("designs", { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbp;
}

async function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const r = fn(t.objectStore(store));
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

export const db = {
  listProjects: () => tx<Project[]>("projects", "readonly", (s) => s.getAll()),
  getProject: (id: string) => tx<Project | undefined>("projects", "readonly", (s) => s.get(id)),
  putProject: (p: Project) => tx("projects", "readwrite", (s) => s.put(p)),
  deleteProject: (id: string) => tx("projects", "readwrite", (s) => s.delete(id)),

  listDesigns: () => tx<SavedDesign[]>("designs", "readonly", (s) => s.getAll()),
  putDesign: (d: SavedDesign) => tx("designs", "readwrite", (s) => s.put(d)),
  deleteDesign: (id: string) => tx("designs", "readwrite", (s) => s.delete(id)),

  getMedia: (id: string) => tx<MediaRecord | undefined>("media", "readonly", (s) => s.get(id)),
  listMedia: () => tx<MediaRecord[]>("media", "readonly", (s) => s.getAll()),
  deleteMedia: (id: string) => tx("media", "readwrite", (s) => s.delete(id)),
  async addMedia(file: File | Blob, kind: MediaRecord["kind"], name?: string): Promise<MediaRecord> {
    const rec: MediaRecord = {
      id: uid(),
      kind,
      name: name ?? (file as File).name ?? "media",
      type: file.type,
      size: file.size,
      blob: file,
      createdAt: Date.now(),
    };
    await tx("media", "readwrite", (s) => s.put(rec));
    return rec;
  },

  /** Remove media blobs that no project references any more. Returns bytes freed. */
  async cleanOrphanMedia(): Promise<{ count: number; bytes: number }> {
    const [projects, media] = await Promise.all([this.listProjects(), this.listMedia()]);
    const used = new Set<string>();
    projects.forEach((p) => {
      if (p.audio.mediaId) used.add(p.audio.mediaId);
      if (p.background.mediaId) used.add(p.background.mediaId);
    });
    (await this.listDesigns()).forEach((d) => d.background.mediaId && used.add(d.background.mediaId));
    let count = 0,
      bytes = 0;
    for (const m of media) {
      if (!used.has(m.id)) {
        await this.deleteMedia(m.id);
        count++;
        bytes += m.size;
      }
    }
    return { count, bytes };
  },
};
