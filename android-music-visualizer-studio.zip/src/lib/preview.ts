import { Analyzer, getDemoTrack, newFrame } from "./audio";
import { loadFonts } from "./fonts";
import { Renderer, type Scene } from "./renderer";
import type { Template } from "./types";

let analyzerP: Promise<Analyzer> | null = null;
export function getDemoAnalyzer(): Promise<Analyzer> {
  if (!analyzerP) analyzerP = getDemoTrack().then((b) => new Analyzer(b));
  return analyzerP;
}

export const templateScene = (t: Template): Scene => ({
  background: t.background,
  effects: t.effects,
  layers: t.layers,
  lyrics: t.lyrics ?? [],
});

const cache = new Map<string, string>();
let chain: Promise<unknown> = Promise.resolve();
let shared: Renderer | null = null;

/** Renders a still frame of a template, driven by FFT analysis of the built-in demo track. */
export function stillFor(t: Template, w = 480, h = 270): Promise<string> {
  const key = `${t.id}-${w}x${h}`;
  const hit = cache.get(key);
  if (hit) return Promise.resolve(hit);
  const job = chain.then(async () => {
    const again = cache.get(key);
    if (again) return again;
    await loadFonts();
    const an = await getDemoAnalyzer();
    if (!shared) shared = new Renderer(document.createElement("canvas"));
    shared.resize(w, h);
    shared.reset();
    const f = newFrame();
    const scene = templateScene(t);
    const end = 12.4;
    for (let i = 36; i >= 0; i--) {
      const time = end - i / 30;
      an.frame(time, f);
      shared.render(scene, time + 2, f, null, 1 / 30);
    }
    const url = shared.canvas.toDataURL("image/jpeg", 0.82);
    cache.set(key, url);
    await new Promise((r) => setTimeout(r, 0));
    return url;
  });
  chain = job.catch(() => {});
  return job;
}

/** Animated live preview used on hover. Returns a stop function. */
export function startLive(canvas: HTMLCanvasElement, t: Template): () => void {
  let stop = false;
  (async () => {
    await loadFonts();
    const an = await getDemoAnalyzer();
    if (stop) return;
    const r = new Renderer(canvas);
    r.resize(canvas.width, canvas.height);
    const f = newFrame();
    const scene = templateScene(t);
    const t0 = performance.now();
    let last = 0;
    const loop = () => {
      if (stop) return;
      const el = (performance.now() - t0) / 1000;
      const tt = 7.8 + (el % 20);
      an.frame(tt, f);
      r.render(scene, tt - 5.8, f, null, Math.min(0.05, el - last || 1 / 60));
      last = el;
      requestAnimationFrame(loop);
    };
    loop();
  })();
  return () => {
    stop = true;
  };
}
