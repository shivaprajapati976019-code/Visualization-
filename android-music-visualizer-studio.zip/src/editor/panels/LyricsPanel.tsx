import { FileText, Hand, Plus, Play, Timer, Trash2, Wand2 } from "lucide-react";
import { useState } from "react";
import { Button, IconBtn, Modal, Section } from "../../components/ui";
import { lyr } from "../../lib/templates";
import type { LyricLine, Project } from "../../lib/types";
import { fmtTime, pickFile, uid } from "../../lib/util";
import { cn } from "../../utils/cn";
import { useTime, type TimeStore, type Updater } from "../state";

interface Props {
  project: Project;
  update: Updater;
  duration: number;
  store: TimeStore;
  seek: (t: number) => void;
  playing: boolean;
  togglePlay: () => void;
  select: (id: string | null) => void;
  toast: (m: string) => void;
}

export function parseLyricsText(raw: string, duration: number): LyricLine[] {
  const rows = raw.split(/\r?\n/);
  const lrc: { t: number; text: string }[] = [];
  for (const r of rows) {
    const m = r.match(/^\s*((?:\[\d+:\d+(?:[.:]\d+)?\])+)\s*(.*)$/);
    if (m) {
      const text = m[2].trim();
      for (const tm of m[1].matchAll(/\[(\d+):(\d+(?:[.:]\d+)?)\]/g)) lrc.push({ t: parseInt(tm[1]) * 60 + parseFloat(tm[2].replace(":", ".")), text });
    }
  }
  if (lrc.length >= 2) {
    lrc.sort((a, b) => a.t - b.t);
    return lrc
      .filter((l) => l.text)
      .map((l, i, arr) => ({ id: uid(), start: l.t, end: Math.min(duration, (arr[i + 1]?.t ?? l.t + 4) - 0.05), text: l.text }))
      .filter((l) => l.end > l.start);
  }
  const lines = rows.map((r) => r.trim()).filter(Boolean);
  const per = Math.max(1.5, Math.min(5, duration / Math.max(1, lines.length)));
  return lines.map((text, i) => ({ id: uid(), start: Math.round(i * per * 10) / 10, end: Math.round((i * per + per - 0.1) * 10) / 10, text }));
}

export function LyricsPanel({ project, update, duration, store, seek, playing, togglePlay, select, toast }: Props) {
  const t = useTime(store);
  const [bulk, setBulk] = useState(false);
  const [text, setText] = useState("");
  const [tap, setTap] = useState<number | null>(null);
  const [order, setOrder] = useState<string[]>([]);
  const lines = [...project.lyrics].sort((a, b) => a.start - b.start);
  const hasLayer = project.layers.some((l) => l.type === "lyrics");

  const setLines = (fn: (l: LyricLine[]) => LyricLine[], key?: string) => update((p) => ({ ...p, lyrics: fn(p.lyrics) }), key);
  const patch = (id: string, pt: Partial<LyricLine>, key?: string) => setLines((ls) => ls.map((l) => (l.id === id ? { ...l, ...pt } : l)), key);
  const r1 = (v: number) => Math.round(v * 10) / 10;

  const ensureLayer = () => {
    if (!hasLayer) {
      const l = lyr({ name: "Lyrics" });
      update((p) => ({ ...p, layers: [...p.layers, l] }));
      select(l.id);
    }
  };

  const tapNext = () => {
    if (tap === null || !order[tap]) return;
    const now = r1(store.t);
    const curId = order[tap];
    const prevId = order[tap - 1];
    const prevStart = project.lyrics.find((l) => l.id === prevId)?.start ?? 0;
    setLines((ls) =>
      ls.map((l) => {
        if (l.id === curId) return { ...l, start: now, end: Math.min(duration, r1(now + 3)) };
        if (l.id === prevId) return { ...l, end: Math.max(prevStart + 0.2, r1(now - 0.05)) };
        return l;
      })
    );
    if (tap + 1 >= order.length) {
      setTap(null);
      toast("Tap sync complete");
    } else setTap(tap + 1);
  };

  return (
    <div>
      <Section title="Lyrics video">
        {!hasLayer && (
          <div className="rounded-xl bg-amber-500/10 p-3 text-xs text-amber-200">
            This project has no lyrics layer yet, so lyrics won’t be displayed.
            <Button size="sm" variant="soft" className="ml-2" onClick={ensureLayer}>
              Add lyrics layer
            </Button>
          </div>
        )}
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="soft"
            size="sm"
            onClick={() => {
              ensureLayer();
              setLines((ls) => [...ls, { id: uid(), start: r1(store.t), end: r1(Math.min(duration, store.t + 3)), text: "New lyric line" }]);
            }}
          >
            <Plus size={14} /> Line at playhead
          </Button>
          <Button variant="soft" size="sm" onClick={() => setBulk(true)}>
            <Wand2 size={14} /> Paste lyrics
          </Button>
          <Button
            variant="soft"
            size="sm"
            onClick={async () => {
              const f = await pickFile(".txt,.lrc,text/plain");
              if (!f) return;
              const parsed = parseLyricsText(await f.text(), duration);
              if (!parsed.length) return toast("No lyric lines found in that file");
              ensureLayer();
              setLines(() => parsed);
              toast(`Imported ${parsed.length} lines from ${f.name}`);
            }}
          >
            <FileText size={14} /> Import .txt / .lrc
          </Button>
          <Button
            variant="soft"
            size="sm"
            disabled={lines.length === 0}
            onClick={() => {
              const per = duration / lines.length;
              setLines((ls) => [...ls].sort((a, b) => a.start - b.start).map((l, i) => ({ ...l, start: r1(i * per), end: r1((i + 1) * per - 0.1) })));
            }}
          >
            <Timer size={14} /> Spread evenly
          </Button>
        </div>
      </Section>

      <Section title="Tap-to-sync">
        <p className="text-xs text-zinc-500">Play the song and tap at the moment each line begins. The previous line ends automatically.</p>
        {tap === null ? (
          <Button
            variant="primary"
            size="sm"
            disabled={lines.length === 0}
            onClick={() => {
              ensureLayer();
              setOrder(lines.map((l) => l.id));
              setTap(0);
              seek(0);
              if (!playing) togglePlay();
            }}
          >
            <Hand size={14} /> Start syncing
          </Button>
        ) : (
          <div className="space-y-2">
            <div className="rounded-xl bg-ink-700 p-3 text-center text-sm">
              <div className="text-[10px] uppercase tracking-wider text-zinc-500">
                Next line {tap + 1} / {order.length}
              </div>
              <div className="mt-1 font-medium">{project.lyrics.find((l) => l.id === order[tap])?.text}</div>
            </div>
            <button onClick={tapNext} className="grad-bg w-full rounded-2xl py-5 text-lg font-bold text-white shadow-lg active:scale-[0.98]">
              TAP
            </button>
            <Button size="sm" variant="ghost" onClick={() => setTap(null)}>
              Stop syncing
            </Button>
          </div>
        )}
      </Section>

      <Section title={`Lines (${lines.length})`} right={lines.length > 0 && <button onClick={() => setLines(() => [])} className="text-[11px] text-zinc-500 hover:text-red-400">Clear all</button>}>
        {lines.length === 0 && <p className="text-xs text-zinc-500">No lyric lines yet.</p>}
        <div className="space-y-2">
          {lines.map((l) => {
            const active = t >= l.start && t < l.end;
            return (
              <div key={l.id} className={cn("rounded-xl border p-2.5", active ? "border-emerald-400/60 bg-emerald-500/10" : "border-white/5 bg-ink-700")}>
                <div className="flex items-start gap-1.5">
                  <textarea
                    value={l.text}
                    rows={1}
                    onChange={(e) => patch(l.id, { text: e.target.value }, "lyr-" + l.id)}
                    className="min-h-8 flex-1 resize-none rounded-lg bg-transparent px-1 py-1 text-sm outline-none focus:bg-black/20"
                  />
                  <IconBtn className="!h-7 !w-7" title="Jump to line" onClick={() => seek(l.start)}>
                    <Play size={13} />
                  </IconBtn>
                  <IconBtn className="!h-7 !w-7 hover:!text-red-400" title="Delete" onClick={() => setLines((ls) => ls.filter((x) => x.id !== l.id))}>
                    <Trash2 size={13} />
                  </IconBtn>
                </div>
                <div className="mt-1.5 grid grid-cols-2 gap-2">
                  {(["start", "end"] as const).map((k) => (
                    <div key={k} className="flex items-center gap-1">
                      <input
                        type="number"
                        step={0.1}
                        min={0}
                        value={l[k]}
                        onChange={(e) => patch(l.id, { [k]: Math.max(0, parseFloat(e.target.value) || 0) }, `lyr-${l.id}-${k}`)}
                        className="w-full min-w-0 rounded-lg border border-white/10 bg-ink-800 px-2 py-1 text-xs outline-none"
                      />
                      <button title={`Set ${k} to playhead`} onClick={() => patch(l.id, { [k]: r1(store.t) })} className="shrink-0 rounded-lg bg-white/5 px-2 py-1 text-[10px] text-zinc-300 hover:bg-white/10">
                        {k === "start" ? "⏵ now" : "⏹ now"}
                      </button>
                    </div>
                  ))}
                </div>
                <div className="mt-1 text-[10px] text-zinc-600">
                  {fmtTime(l.start, true)} → {fmtTime(l.end, true)}
                </div>
              </div>
            );
          })}
        </div>
      </Section>

      <Modal open={bulk} onClose={() => setBulk(false)} title="Paste lyrics">
        <p className="mb-3 text-xs text-zinc-400">One line per row. Lines are spread across the song; you can refine timing afterwards or use Tap-to-sync. LRC timestamps like [01:23.40] are detected automatically.</p>
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={10} className="w-full rounded-xl border border-white/10 bg-ink-700 p-3 text-sm outline-none focus:border-accent" placeholder={"First line\nSecond line\n…"} />
        <div className="mt-4 flex justify-end gap-2">
          <Button onClick={() => setBulk(false)}>Cancel</Button>
          <Button
            variant="primary"
            onClick={() => {
              const parsed = parseLyricsText(text, duration);
              if (!parsed.length) return toast("Nothing to import");
              ensureLayer();
              setLines(() => parsed);
              setBulk(false);
              setText("");
            }}
          >
            Create lines
          </Button>
        </div>
      </Modal>
    </div>
  );
}
