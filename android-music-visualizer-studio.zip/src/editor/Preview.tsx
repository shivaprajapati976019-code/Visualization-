import { useEffect, useRef, useState, type RefObject } from "react";
import type { Bounds, Renderer } from "../lib/renderer";
import { aspectRatio } from "../lib/templates";
import type { Layer, Project } from "../lib/types";
import { clamp } from "../lib/util";

interface Props {
  canvasRef: RefObject<HTMLCanvasElement | null>;
  rendererRef: RefObject<Renderer | null>;
  project: Project;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onMove: (id: string, x: number, y: number) => void;
  onScale: (id: string, s: number) => void;
}

type Drag = { mode: "move"; id: string; dx: number; dy: number } | { mode: "scale"; id: string; startScale: number; startDist: number };

export function Preview({ canvasRef, rendererRef, project, selectedId, onSelect, onMove, onScale }: Props) {
  const wrap = useRef<HTMLDivElement>(null);
  const overlay = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ w: 320, h: 180 });
  const drag = useRef<Drag | null>(null);
  const projRef = useRef(project);
  projRef.current = project;
  const selRef = useRef(selectedId);
  selRef.current = selectedId;

  useEffect(() => {
    const el = wrap.current!;
    const ro = new ResizeObserver(() => {
      const r = aspectRatio(project.aspect);
      const aw = el.clientWidth - 16;
      const ah = el.clientHeight - 16;
      let w = aw,
        h = aw / r;
      if (h > ah) {
        h = ah;
        w = ah * r;
      }
      setSize({ w: Math.max(40, Math.floor(w)), h: Math.max(40, Math.floor(h)) });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [project.aspect]);

  const toCanvas = (e: { clientX: number; clientY: number }) => {
    const r = overlay.current!.getBoundingClientRect();
    const rd = rendererRef.current;
    const W = rd?.W ?? 1,
      H = rd?.H ?? 1;
    return { x: ((e.clientX - r.left) / r.width) * W, y: ((e.clientY - r.top) / r.height) * H, k: W / r.width, W, H };
  };

  const hit = (b: Bounds, px: number, py: number, pad: number) => {
    const a = (-b.rot * Math.PI) / 180;
    const dx = px - b.x,
      dy = py - b.y;
    const lx = dx * Math.cos(a) - dy * Math.sin(a);
    const ly = dx * Math.sin(a) + dy * Math.cos(a);
    return Math.abs(lx) <= b.w / 2 + pad && Math.abs(ly) <= b.h / 2 + pad;
  };

  const handlePos = (b: Bounds) => {
    const a = (b.rot * Math.PI) / 180;
    const cx = b.w / 2,
      cy = b.h / 2;
    return { x: b.x + cx * Math.cos(a) - cy * Math.sin(a), y: b.y + cx * Math.sin(a) + cy * Math.cos(a) };
  };

  const down = (e: React.PointerEvent) => {
    const rd = rendererRef.current;
    if (!rd) return;
    const p = toCanvas(e);
    const sel = selRef.current;
    const layers = projRef.current.layers;
    if (sel) {
      const b = rd.bounds.get(sel);
      const L = layers.find((l) => l.id === sel);
      if (b && L) {
        const hp = handlePos(b);
        if (Math.hypot(hp.x - p.x, hp.y - p.y) < 22 * p.k) {
          drag.current = { mode: "scale", id: sel, startScale: L.scale, startDist: Math.max(10, Math.hypot(p.x - b.x, p.y - b.y)) };
          (e.target as Element).setPointerCapture(e.pointerId);
          return;
        }
      }
    }
    for (let i = layers.length - 1; i >= 0; i--) {
      const L = layers[i];
      const b = rd.bounds.get(L.id);
      if (b && hit(b, p.x, p.y, 8 * p.k)) {
        onSelect(L.id);
        drag.current = { mode: "move", id: L.id, dx: p.x - L.x * p.W, dy: p.y - L.y * p.H };
        (e.target as Element).setPointerCapture(e.pointerId);
        return;
      }
    }
    onSelect(null);
  };
  const move = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const p = toCanvas(e);
    if (d.mode === "move") onMove(d.id, clamp((p.x - d.dx) / p.W, -0.2, 1.2), clamp((p.y - d.dy) / p.H, -0.2, 1.2));
    else {
      const b = rendererRef.current?.bounds.get(d.id);
      if (b) onScale(d.id, clamp((d.startScale * Math.hypot(p.x - b.x, p.y - b.y)) / d.startDist, 0.1, 5));
    }
  };
  const up = () => (drag.current = null);

  // selection overlay
  useEffect(() => {
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const c = overlay.current;
      const rd = rendererRef.current;
      if (!c || !rd) return;
      const w = c.clientWidth,
        h = c.clientHeight;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) {
        c.width = Math.round(w * dpr);
        c.height = Math.round(h * dpr);
      }
      const ctx = c.getContext("2d")!;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const sel = selRef.current;
      const b = sel ? rd.bounds.get(sel) : null;
      if (!b) return;
      const k = w / rd.W;
      ctx.save();
      ctx.translate(b.x * k, b.y * k);
      ctx.rotate((b.rot * Math.PI) / 180);
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 4]);
      const bw = Math.min(b.w * k, w * 3),
        bh = Math.min(b.h * k, h * 3);
      ctx.strokeRect(-bw / 2, -bh / 2, bw, bh);
      ctx.setLineDash([]);
      ctx.fillStyle = "#8b5cf6";
      ctx.strokeStyle = "#fff";
      ctx.beginPath();
      ctx.arc(bw / 2, bh / 2, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    };
    draw();
    return () => cancelAnimationFrame(raf);
  }, [rendererRef]);

  const wheel = (e: React.WheelEvent) => {
    const sel = selRef.current;
    if (!sel) return;
    const L = projRef.current.layers.find((l: Layer) => l.id === sel);
    if (L) onScale(sel, clamp(L.scale * (e.deltaY < 0 ? 1.05 : 0.95), 0.1, 5));
  };

  return (
    <div ref={wrap} className="grid min-h-0 flex-1 place-items-center bg-[radial-gradient(circle_at_center,#14141c,#07070a)] p-2">
      <div className="relative shadow-2xl shadow-black/60 ring-1 ring-white/10" style={{ width: size.w, height: size.h }}>
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full bg-black" />
        <canvas
          ref={overlay}
          className="absolute inset-0 h-full w-full touch-none"
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={up}
          onPointerCancel={up}
          onWheel={wheel}
        />
      </div>
    </div>
  );
}
