import { Play } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { startLive, stillFor } from "../lib/preview";
import type { Template } from "../lib/types";
import { cn } from "../utils/cn";

export function TemplateCard({ template, onClick, className }: { template: Template; onClick?: () => void; className?: string }) {
  const [src, setSrc] = useState<string | null>(null);
  const [hover, setHover] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let alive = true;
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (es) => {
        if (es[0].isIntersecting) {
          io.disconnect();
          stillFor(template).then((u) => alive && setSrc(u));
        }
      },
      { rootMargin: "200px" }
    );
    io.observe(el);
    return () => {
      alive = false;
      io.disconnect();
    };
  }, [template]);

  useEffect(() => {
    if (!hover || !cv.current) return;
    return startLive(cv.current, template);
  }, [hover, template]);

  return (
    <button
      ref={ref as unknown as React.Ref<HTMLButtonElement>}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className={cn("group block overflow-hidden rounded-2xl border border-white/[0.06] bg-ink-800 text-left transition hover:-translate-y-0.5 hover:border-accent/50 hover:shadow-xl hover:shadow-accent/10", className)}
    >
      <div className="relative aspect-video overflow-hidden bg-ink-700">
        {src ? <img src={src} alt={template.name} className="h-full w-full object-cover" /> : <div className="h-full w-full animate-pulse bg-ink-600" />}
        {hover && <canvas ref={cv} width={480} height={270} className="absolute inset-0 h-full w-full object-cover" />}
        <span className="absolute left-2 top-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-white backdrop-blur">{template.category}</span>
        <span className="absolute bottom-2 right-2 grid h-8 w-8 place-items-center rounded-full bg-white/90 text-black opacity-0 transition group-hover:opacity-100">
          <Play size={14} fill="currentColor" />
        </span>
      </div>
      <div className="p-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="truncate text-sm font-semibold text-white">{template.name}</h3>
          <div className="flex shrink-0 -space-x-1">
            {template.palette.slice(0, 3).map((c) => (
              <span key={c} className="h-3.5 w-3.5 rounded-full border border-black/50" style={{ background: c }} />
            ))}
          </div>
        </div>
        <p className="mt-0.5 truncate text-xs text-zinc-500">{template.styleLabel}</p>
      </div>
    </button>
  );
}
